package com.te.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.te.jpawithhibernate.beans.InternsInfo;

public class ReadNames {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("interns");
		EntityManager manager = factory.createEntityManager();

		String read = " select name from InternsInfo ";

		Query query = manager.createQuery(read);

		List<String> name = query.getResultList();

		for (String info : name) {

			System.out.println(info);

		}

		manager.close();
		factory.close();
	}
}
