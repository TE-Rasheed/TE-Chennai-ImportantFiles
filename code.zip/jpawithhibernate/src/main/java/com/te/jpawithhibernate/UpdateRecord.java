package com.te.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.jpawithhibernate.beans.InternsInfo;

public class UpdateRecord {

	public static void main(String[] args) {

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		try {
			factory = Persistence.createEntityManagerFactory("interns");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			InternsInfo info =manager.find(InternsInfo.class,120);
			info.setName("Sravanthi");
			info.setGender("F");
			info.setEmail("sravanthi@gmail.com");
			info.setBloodGroup("AB+");
			info.setDesignation("Architect");
			transaction.commit();
			System.out.println("Updated Successfully");
			
			
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		finally {
			try {
				manager.close();
				factory.close();
				
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}