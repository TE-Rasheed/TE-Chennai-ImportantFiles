package com.te.jpawithhibernate.beans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import lombok.Data;

@Entity
@Table(name = "interns")
@Data
public class InternsInfo  implements Serializable{
	
	public InternsInfo() {}
 
	@Column
	private String name;
	
	@Id
	@Column
	private Integer id;
	
	@Column(name = "dob")
	private Date dateOfBirth;
	
	@Column
	private String gender;
	
	@Column(name = "role" )
	private String designation;
	
	@Column(name = "mobile")
	private Long mobileNo;
	
	@Column
	private Double salary;
	
	@Column
	private Integer deptId;
	
	@Column(name = "blood_group")
	private String bloodGroup;
	
	@Column
	private String email;
	
	@Column(name = "Comm")
	private Integer commission;
	
	@Column(name = "MGR")
	private Integer reportingManager;
	
}
