package com.te.jpawithhibernate.beans;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class GetInternsInfo {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("interns");
		EntityManager em = emf.createEntityManager();
		
		//InternsInfo info = em.find(InternsInfo.class, 30);
		InternsInfo info = em.getReference(InternsInfo.class, 40);
		
		if(info != null) {
			System.out.println(info.getName());
			System.out.println(info.getId());
			System.out.println(info.getGender());
			System.out.println(info.getDateOfBirth());
			System.out.println(info.getMobileNo());
			System.out.println(info.getSalary());
			System.out.println(info.getDeptId());
			System.out.println(info.getBloodGroup());
			System.out.println(info.getEmail());
			System.out.println(info.getCommission());
			
		}
		
		try {
			
			emf.close();
			em.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
