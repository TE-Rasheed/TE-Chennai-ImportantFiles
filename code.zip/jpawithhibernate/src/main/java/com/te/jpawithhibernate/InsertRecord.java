package com.te.jpawithhibernate;

import java.sql.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.te.jpawithhibernate.beans.InternsInfo;

public class InsertRecord {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		
		InternsInfo info = new InternsInfo();
		
		info.setName("Irfan");
		info.setId(120);
		info.setDateOfBirth(Date.valueOf("1995-06-24"));
		info.setDesignation("Developer");
		info.setGender("M");
		info.setMobileNo(9076453721L);
		info.setSalary(55000.00);
		info.setDeptId(500);
		info.setBloodGroup("AB-");
		info.setEmail("irfan@gmail.com");
		info.setCommission(2500);
		info.setReportingManager(50);
		
		try {
			factory = Persistence.createEntityManagerFactory("interns");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(info);
			transaction.commit();
			System.out.println("Inserted Successfully");
			
			
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		finally {
			try {
				manager.close();
				factory.close();
				
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
