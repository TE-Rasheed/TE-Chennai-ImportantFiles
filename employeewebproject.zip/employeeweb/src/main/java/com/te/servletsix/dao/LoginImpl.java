package com.te.servletsix.dao;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.servletsix.bean.EmployeeInfo;

public class LoginImpl extends HttpServlet {

	public boolean validate(String uname, String pwd) {
		
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		try {
			factory = Persistence.createEntityManagerFactory("work");
			manager = factory.createEntityManager();

		String Url = " from EmployeeInfo where username=:name and password=:pass";
		Query query = manager.createQuery(Url);
		query.setParameter("name", uname);
		query.setParameter("pass", pwd);
		Object obj = query.getSingleResult();
		if (obj != null) {
			return true;
		}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

}
