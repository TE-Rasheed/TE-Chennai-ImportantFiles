package com.te.servletsix.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.servletsix.bean.EmployeeInfo;

public class RegisterImpl {

	public boolean createDetails(String name, String uname, String pwd, Integer age, String email, String role,
			Double salary) {

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;

		try {
			factory = Persistence.createEntityManagerFactory("work");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();

			EmployeeInfo info = new EmployeeInfo();
			info.setName(name);
			info.setUsername(uname);
			info.setPassword(pwd);
			info.setAge(age);
			info.setEmail(email);
			info.setRole(role);
			info.setSalary(salary);

			transaction.begin();
			manager.persist(info);
			transaction.commit();
			return true;

		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
			return false;
			
			
		}

		finally {
			try {
				if (factory != null) {
					factory.close();
				}
				if (manager != null) {
					manager.close();
				}

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
