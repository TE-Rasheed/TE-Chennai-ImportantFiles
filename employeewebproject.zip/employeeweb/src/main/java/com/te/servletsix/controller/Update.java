package com.te.servletsix.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.servletsix.dao.UpdateEmail;

@WebServlet("/update")
public class Update extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String change1 = req.getParameter("change");
		if (change1.equals("mail")) {
			email(req, resp);
		}
	}

	public void email(HttpServletRequest req, HttpServletResponse resp) throws IOException,ServletException {

		String uname = req.getParameter("username");
		String email = req.getParameter("email");
		UpdateEmail mail = new UpdateEmail();
		if (mail.editEmail(uname, email)) {
			resp.sendRedirect("./editsuccess.jsp");
		}

	}
}
