package com.te.servletsix.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.te.servletsix.bean.EmployeeInfo;

public class ViewDetails {

	public List<EmployeeInfo> showRecord(String name) {

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		List<EmployeeInfo> result = null;
		
		try {
			factory = Persistence.createEntityManagerFactory("work");
			manager = factory.createEntityManager();

			String fetch = " from EmployeeInfo where username=:name";
			Query query = manager.createQuery(fetch);
			query.setParameter("name", name);
			result = query.getResultList();
			
			if (result != null) {
				return result;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		factory.close();
		manager.close();
		
		return null;
	}

}
