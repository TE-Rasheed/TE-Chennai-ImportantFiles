package com.te.exceptions.throwtest;

import com.te.exceptions.exp.InvalidCredentialsException;

public class LoginToAdmin {

	public void login(String user, String pwd){

		if (user.equalsIgnoreCase("admin")) {
			if (pwd.equalsIgnoreCase("admin123")) {
				System.out.println("logged in Successfully");
			} else {
				throw new InvalidCredentialsException("Wrong Password");
			}
		} else {
			throw new InvalidCredentialsException("Wrong Credentials");
		}
	}
}
