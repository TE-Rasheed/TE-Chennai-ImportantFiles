package com.te.exceptions.checked;

import com.te.exceptions.Employee;

public class ClassLoaderTest {

	public static void main(String[] args) {

		try {
//			 if class is found it will be loaded successfully else exception will be handled in catch block
			Employee employee = (Employee) Class.forName("com.te.exceptions.Employee").newInstance();
			System.out.println(employee);
			System.out.println("Loaded Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
