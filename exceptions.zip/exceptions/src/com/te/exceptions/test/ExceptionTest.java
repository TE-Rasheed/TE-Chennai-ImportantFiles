package com.te.exceptions.test;

import java.util.Scanner;

public class ExceptionTest {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number");
		int number = Integer.parseInt(scanner.next());

		try {
			int a = 10;
			int b = 0;
			int c = a / b;
			System.out.println(c);

			System.out.println("This is executed");
			String name = null;

			System.out.println(name.length());

		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}

		System.out.println("Hi");
	}
}
