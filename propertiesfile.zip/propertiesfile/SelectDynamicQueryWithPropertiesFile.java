package com.te.jdbc.propertiesfile;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class SelectDynamicQueryWithPropertiesFile {

	public static void main(String[] args) {
	
		FileInputStream inputStream= null;
		PreparedStatement preparedStatement = null;
		Connection connection = null;
		ResultSet resultSet = null;
		try {
			inputStream = new FileInputStream("dbInfo.properties");
			Properties pro = new Properties();
			pro.load(inputStream);
			
			//step1
			Class.forName(pro.getProperty("driver"));
			
			//step2
			DriverManager.getConnection(pro.getProperty("dbUrl"),pro);
			
			//step3
			String query = "select * from intern where id = ? ";
			
			preparedStatement=connection.prepareStatement(query);
			
			preparedStatement.setInt(1, Integer.parseInt(args[0]));
			
			resultSet =preparedStatement.executeQuery();
			
			//step4
			if(resultSet.next()) {
				System.out.println(resultSet.getString("name"));
				System.out.println(resultSet.getString("id"));
				System.out.println(resultSet.getString("dob"));
				
				
			}
		}catch(Exception e) {
			e.printStackTrace();
			
			
		}finally {
			try {
				if(connection!=null) {
					connection.close();
				}
				if(preparedStatement!=null) {
					preparedStatement.close();
			}
				if(resultSet!=null) {
					resultSet.close();
					
				}
		}catch(Exception e2) {
			e2.printStackTrace();
		}
	}
}
}
