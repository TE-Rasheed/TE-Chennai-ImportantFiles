package com.te.jdbc.propertiesfile;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Statement;

public class JdbcDeleteQueryStatic {

	public static void main(String[] args) {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");

		    System.out.println("driver loaded");
		      	
			//step2
			String dburl = "jdbc:mysql://localhost:3306/technoelevate";
			
			Connection connection = DriverManager.getConnection(dburl, "root","root");
		
			//step3
			 Statement statement = connection.createStatement();
			
			String query = "delete from intern where id = 132 ";
			  int result =  statement.executeUpdate(query +" row deleted");
			 
			 
			 //step4
		
				 System.out.println(result);
				
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
