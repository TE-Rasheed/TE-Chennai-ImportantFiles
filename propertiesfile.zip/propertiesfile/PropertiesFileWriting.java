package com.te.jdbc.propertiesfile;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Properties;

public class PropertiesFileWriting {
	public static void main(String[] args) {
		
		try {
			FileOutputStream fileOutputStream = new FileOutputStream("naveen.properties");

			Properties pro = new Properties();
			pro.setProperty("user", "root");
			pro.setProperty("password", "root");
			pro.setProperty("dbUrl", "jdbc:mysql://localhost:3306/technoelevate");
			pro.setProperty("driver", "com.mysql.jdbc.Driver");
			
			pro.store(fileOutputStream, "Db information");
			System.out.println("sucess");
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

}
