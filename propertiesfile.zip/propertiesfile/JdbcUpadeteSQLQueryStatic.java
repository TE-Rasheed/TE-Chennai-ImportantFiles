package com.te.jdbc.propertiesfile;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JdbcUpadeteSQLQueryStatic {
	
	public static void main(String[] args) {
		
		try {
			//step1
		   Class.forName("com.mysql.jdbc.Driver");

		    System.out.println("driver loaded");
		      	
			//step2
			String dburl = "jdbc:mysql://localhost:3306/technoelevate";
			
			Connection connection = DriverManager.getConnection(dburl, "root","root");
		
			//step3
			 Statement statement = connection.createStatement();
			
			String query = "update intern set id =19 where id = 10 ";
			  int result =  statement.executeUpdate(query);
			 
			 
			 //step4
		
				 System.out.println(result + " row inserted");
				 
			 
			 
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
