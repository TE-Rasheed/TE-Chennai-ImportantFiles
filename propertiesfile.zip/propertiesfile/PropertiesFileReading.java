package com.te.jdbc.propertiesfile;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Properties;

public class PropertiesFileReading {
	public static void main(String[] args) {
		
		try {
			FileInputStream file = new FileInputStream("dbInfo.properties");
			
			Properties pro = new Properties();
			pro.load(file);
			
			System.out.println(pro.getProperty(""));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
