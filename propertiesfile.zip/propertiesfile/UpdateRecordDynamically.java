package com.te.jdbc.propertiesfile;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

public class UpdateRecordDynamically {

	public static void main(String[] args) {

		Connection connection = null;
		FileInputStream inputStream = null;
		PreparedStatement preparedStatement = null;
		try {
			inputStream = new FileInputStream("dbInfo.properties");

			Properties prop = new Properties();
			prop.load(inputStream);

			// step1
			Class.forName(prop.getProperty("driver"));

			// step2
			connection = DriverManager.getConnection(prop.getProperty("dbUrl"), prop);

			//// step3
			String query = "update intern set name = ? where id= ?";

			preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, args[0]);
			preparedStatement.setInt(2, Integer.parseInt(args[1]));
			
			int res = preparedStatement.executeUpdate();

			// step4
			if (res == 1) {
				System.out.println("data updated sucessfully");
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		// step 5
		finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (inputStream != null) {
					inputStream.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();

				}

			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

	}
}