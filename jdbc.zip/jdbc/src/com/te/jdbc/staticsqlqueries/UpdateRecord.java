package com.te.jdbc.staticsqlqueries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateRecord {

	public static void main(String[] args) {

		try {
			// step 1: creating object of driver by using 1st type
			// Driver ref=new Driver();
			// DriverManager.deregisterDriver(ref);

			Class.forName("com.mysql.jdbc.Driver").newInstance();

			System.out.println("driver loaded");

			// step:2 get db connection via driver
			String dburl = "jdbc:mysql://localhost:3306/technoelevate?useSSL=false&user=root&password=root";
			Connection connection = DriverManager.getConnection(dburl);

			// STEP 3; ISSUE SQL QUERIES VIA CONNECTION
			String query = "update  interns set name='vicky' where id=110";

			Statement statement = connection.createStatement();

			int result = statement.executeUpdate(query);

			// step4: process the result
			System.out.println(result + "row upadted");

		} catch (Exception e) {
			e.printStackTrace();

		}
	}
}