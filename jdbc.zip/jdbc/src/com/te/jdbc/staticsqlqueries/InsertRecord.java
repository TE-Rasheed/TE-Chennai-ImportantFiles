package com.te.jdbc.staticsqlqueries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertRecord {

	public static void main(String[] args) {
		Connection connection = null;
		Statement statement = null;
		try {
			//step1
			Class.forName("com.mysql.jdbc.Driver");
			
			//step2
			String dburl = "jdbc:mysql://localhost:3306/technoelevate";
			
			connection = DriverManager.getConnection(dburl, "root", "root");
			
			//step3
			
			String query = "insert into interns values('Irfan',110,'1990-02-20','M','JFS',9028356718,89356.50,200,'A+','Irfan@gmail.com',2000,400)";
			
			statement = connection.createStatement();
			
			int result = statement.executeUpdate(query);
			
			//step 4
			
			System.out.println(result +"No of rowa affected");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
