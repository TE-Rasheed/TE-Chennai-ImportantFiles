package com.te.jdbc.staticsqlqueries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Driver {

	public static void main(String[] args) {
		Connection connection = null;
		Statement stmt = null;
		ResultSet resultSet = null;
		
		try {
			// step 1: creating object of driver by using 1st type
			// Driver ref=new Driver();
			// DriverManager.deregisterDriver(ref);

			Class.forName("com.mysql.jdbc.Driver").newInstance();

			System.out.println("driver loaded");

			// step:2 get db connection via driver
			String dburl = "jdbc:mysql://localhost:3306/technoelevate" + "?user=root&password=root";
			connection = DriverManager.getConnection(dburl);

			// sep3 issue sql queries via connection
			String query = "select * from interns";

			stmt = connection.createStatement();

			resultSet = stmt.executeQuery(query);

			// step4 process the Result via SQL queries
			int i = 0;
			while (resultSet.next()) {

				System.out.println("-------------" + i + "--------------------");
				System.out.println("Name   : " + resultSet.getString("name"));
				System.out.println("Id     : " + resultSet.getInt("id"));
				System.out.println("DOB    : " + resultSet.getDate("DOB"));
				System.out.println("Gender : " + resultSet.getString("gender"));
				System.out.println("Role   : " + resultSet.getString("Role"));
				System.out.println("Mobile : " + resultSet.getLong("DOB"));
				System.out.println("Salary : " + resultSet.getDouble("salary"));
				System.out.println("DeptId : " + resultSet.getInt("deptid"));
				System.out.println("blood G: " + resultSet.getString("Blood_Group"));
				System.out.println("Email  : " + resultSet.getString("Email"));
				System.out.println("Comm   : " + resultSet.getInt("Comm"));
				System.out.println("MGR    : " + resultSet.getInt("Mgr"));
				System.out.println("-------------" + i + "--------------------");
				i++;

			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		finally {
			try {
				
				if(connection != null) {
					connection.close();
				}
				if(stmt != null) {
					stmt.close();
				}
				if(resultSet != null) {
					resultSet.close();
				}
				
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
