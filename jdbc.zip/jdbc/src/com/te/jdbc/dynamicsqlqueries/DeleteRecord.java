package com.te.jdbc.dynamicsqlqueries;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

public class DeleteRecord {

	public static void main(String[] args) {

		FileInputStream input = null;
		Connection conn = null;
		PreparedStatement preparedStatement = null;

		try {

			input = new FileInputStream("dbInfo.properties");
			Properties prop = new Properties();
			prop.load(input);

			// step1
			Class.forName(prop.getProperty("driver"));

			// step2
			conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop);

			// step3
			String query = "delete from interns where id=?";
			preparedStatement = conn.prepareStatement((query));

			
			preparedStatement.setInt(1, Integer.parseInt(args[0]));

			int res = preparedStatement.executeUpdate();

			// step4
			if (res == 1) {

				System.out.println("Record deleted Successfully");

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (conn != null) {
					conn.close();
				}
				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (input != null) {
					input.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
