package com.te.jdbc.propertiesfile;

import java.io.FileInputStream;
import java.util.Properties;

public class readPropertiesFile {

	public static void main(String[] args) throws Exception {
		FileInputStream inputStream = new FileInputStream("dbInfo.properties");
		
		Properties prop = new Properties();
		
		prop.load(inputStream);
		System.out.println(prop.get("User"));
		System.out.println(prop.get("Password"));
		System.out.println(prop.get("dbUrl"));
		System.out.println(prop.get("driver"));

	}
}
