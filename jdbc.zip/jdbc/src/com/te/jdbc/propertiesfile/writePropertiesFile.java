package com.te.jdbc.propertiesfile;

import java.io.FileOutputStream;
import java.util.Properties;

public class writePropertiesFile {

	public static void main(String[] args) throws Exception {
		
		FileOutputStream outputStream = new FileOutputStream("dbInfo.properties");
		Properties prop = new Properties();
		
		prop.setProperty("User", "root");
		prop.setProperty("Password", "root");
		prop.setProperty("dbUrl", "jdbc:mysql://localhost:3306/technoelevate");
		prop.setProperty("driver", "com.mysql.jdbc.Driver");
		
		prop.store(outputStream,"DB Information");
		System.out.println("  success ");
	}
}
