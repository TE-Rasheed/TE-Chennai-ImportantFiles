package com.te.ems.customeexception;

public class EmployeeException extends RuntimeException {

	public EmployeeException(String msg) {
		super(msg);
	}
}
