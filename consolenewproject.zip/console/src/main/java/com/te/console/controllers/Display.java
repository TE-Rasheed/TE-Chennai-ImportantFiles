package com.te.console.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.console.beans.Employee;
import com.te.console.dao.DeleteDetails;
import com.te.console.dao.LoginImpl;
import com.te.console.dao.ViewDetails;

@WebServlet("/display") 
public class Display extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			authentication(req, resp);
    }

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		
		ViewDetails view = new ViewDetails();
		DeleteDetails delete = new DeleteDetails();
		String action = req.getParameter("action");
		String name = req.getParameter("name");
		if (action.equals("show")) {
			
			List<Employee> record = view.showRecord(name);
			
			for (Employee employeeInfo : record) {
				req.setAttribute("name", employeeInfo.getName());
				req.setAttribute("uname", employeeInfo.getUsername());
				req.setAttribute("pass", employeeInfo.getPassword());
				req.setAttribute("age", employeeInfo.getAge());
				req.setAttribute("email", employeeInfo.getEmail());
				req.setAttribute("role", employeeInfo.getRole());
				req.setAttribute("salary", employeeInfo.getSalary());
			}
			req.getRequestDispatcher("./viewdetails.jsp").include(req, resp);
		} else if (action.equals("delete")) {
			if (delete.deleteRecord(name)) {
				resp.sendRedirect("./home");
			} else {
				out.println("your account not deleted");
			}
		} else if (action.equals("update")) {
			
		}
		
	}
	
	public void authentication(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();

		String name = req.getParameter("username");
		String pass = req.getParameter("password");

		LoginImpl test = new LoginImpl();
		if (test.validate(name, pass)) {
			out.println("LoginSuccesfull");
			req.setAttribute("uname", req.getParameter("username"));
			req.getRequestDispatcher("./LoginSuccess.jsp").include(req, resp);
			
        } else {
			out.println("login not successfull");
		}
	}
}

