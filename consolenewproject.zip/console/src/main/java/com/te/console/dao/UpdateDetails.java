package com.te.console.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateDetails {
	
	public void updateRecord(String uname) {
		
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			factory = Persistence.createEntityManagerFactory("employee");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			String update = "update EmployeeInfo set name = :name ,salary = :salary where username = :uname";
			Query query = manager.createQuery(update);
			Scanner scanner = new Scanner(System.in);
			System.out.println("enter the name");
			String name = scanner.next();
			scanner.nextLine();
			System.out.println("enter the salary");
			Double salary = scanner.nextDouble();
			query.setParameter("name", name);
			query.setParameter("salary", salary);
			query.setParameter("uname", uname);
			int result = query.executeUpdate();
			transaction.commit();
			System.out.println("succesfully updated");
		} catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			try {
				if (factory != null) {
					factory.close();
				}
				if (manager != null) {
					manager.close();
				}

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

}
