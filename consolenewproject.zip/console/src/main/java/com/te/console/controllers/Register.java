package com.te.console.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.te.console.beans.Employee;

@WebServlet("/registerprocess")
public class Register extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;

		try {
			factory = Persistence.createEntityManagerFactory("employee");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			
			Employee info = new Employee();
			info.setName(req.getParameter("firstname"));
			info.setUsername(req.getParameter("username"));
			info.setPassword(req.getParameter("pwd"));
			info.setAge(Integer.parseInt(req.getParameter("age")));
			info.setEmail(req.getParameter("email"));
			info.setRole(req.getParameter("role"));
			info.setSalary(Double.parseDouble(req.getParameter("salary")));

			transaction.begin();
			manager.persist(info);
			transaction.commit();
			String Url = "./RegisterSuccess.jsp";
			resp.sendRedirect(Url);
			} catch (Exception e) {
				out.println("not successfull");
			}
	}
}	