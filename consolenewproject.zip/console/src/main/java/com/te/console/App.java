package com.te.console;

public class App {

}
