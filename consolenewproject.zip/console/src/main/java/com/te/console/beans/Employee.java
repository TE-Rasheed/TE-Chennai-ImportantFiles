package com.te.console.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "employee")
@Data
public class Employee implements Serializable{

public Employee() {}
	
	@Column
	private String name;
	
	@Id
	@Column
	private String username;
	
	@Column
	private String password;
	
	@Column
	private Integer age;
	
	@Column
	private String email;
	
	@Column
	private String role;
	
	@Column
	private Double salary;

}
