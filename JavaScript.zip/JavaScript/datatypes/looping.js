var arr1 = [,2,3,4,5,,7,9];
arr1["x"] = 100;
console.log(arr1);

var obj = {
    name:"abc",
    age:19
}

for(var data of arr1  ){
    if (data === 7) {
        continue; // both continue and break
    }
    console.log(data);
}

var arr = [,20,30,40,,50,70,90];
arr["name"] = 100
for(var x in arr){
    if (x == 2) {
        continue; // both continue and break
    }
    console.log(arr[x]);   
}

for (var key in obj) {
    
   console.log(typeof key);
   console.log(obj[key]);
}