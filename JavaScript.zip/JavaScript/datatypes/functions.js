//Named Functions

function first() {
  console.log("This is named Functions");
}
// first();

function second(a, b) {
  console.log(a + b);
  return a + b;
}
// var res = second(10, 20);
// console.log(res);

// console.log(" function Expression ");

var greet = function (name) {
  console.log("Good Afternoon ", name);
  return "bye";
};
// var op = greet("Paul");
// console.log(op);

// console.log(" IIFE ");
(function (name) {
  console.log(name);
  console.log("Inside the IIFE");
});

// console.log("Arrow Functions");

var arrFunction = input=>{
    console.log(input);
    console.log("This is Arrow Function");
    return 0;
}

// console.log(arrFunction("Arr"));

var a = 10
var b = 10

console.log( a !== b ); //false
