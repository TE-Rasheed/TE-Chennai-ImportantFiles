var currentDate = new Date();
console.log(currentDate);

var millSecDate = new Date(0);
console.log(millSecDate);

var customDate = new Date(1998,09,21);
console.log(customDate);

var stringDate = new Date("August 15,1947 12:00:00");
console.log(stringDate);

