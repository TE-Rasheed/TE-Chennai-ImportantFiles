var arr1 = [1,2,3,4,5,"Str1" , "str2" , null , true];
console.log(arr1);
arr1[13] = "new";
console.log(arr1);
// ------------------------------------------------------
var arr2  = new Array();
console.log(arr2); //empty

for(var i=0;i<11;i++){
    arr2[i] = i;
}

console.log(arr2); //length 11
// ------------------------------------------------------
var arr3 = new Array(1,2,3);
console.log(arr3);

