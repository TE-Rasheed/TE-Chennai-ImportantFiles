var num = 24; //number
console.log(num);

// var loc = "chennai"; // string
// var loc = 'BLR';
var loc = `Hyd`;
console.log(loc);

var userName = "Muttu";
var userLoc = "Las Vegas";

var output = `My name is ${userName}  from ${userLoc}`; //template String
console.log(output); 

var isCleared = false; // boolean
console.log(isCleared);

var hasChildern = null;
console.log(hasChildern);

var gender; //undefined
console.log(gender);
