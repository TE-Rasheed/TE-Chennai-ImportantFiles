var human = {
    name:"Harikrishnan",
    gender:"Male",
    weight:100,
    height:6.0,
    hobbies:["watching serial","music" ,"dancing" ],
    isMarried:true,
    hasChildren:0,
    dob:new Date().toDateString(),
}

console.log("JS Object - " ,human);

var humanJson = JSON.stringify(human);

console.log("JSON Object " , humanJson);


var jsOb = JSON.parse(humanJson);
 
localStorage.setItem("user" , humanJson); // insert data
var data =localStorage.getItem("user"); // get the data
console.log(JSON.parse(data));

// localStorage.clear();// clear the localStorage
console.log(localStorage.key(0)); // fetches the key at that index in the form of string 
localStorage.removeItem("data");
console.log(localStorage.length);

sessionStorage.setItem("user", humanJson);
