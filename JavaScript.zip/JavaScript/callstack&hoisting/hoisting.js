console.log(brand);
var brand = "HRX";

console.log(arr);
var arr = [1,2,3,4];

//var brand;
//log(brand)
//brand= "xxxx"

function getData(){
                        // var key
    console.log(key);   //log(key)
    var key = 10;       // key =10
}

getData();