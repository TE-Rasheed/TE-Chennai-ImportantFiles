function first() {
  setTimeout(() => {
    console.log(" ---- app started ----"); //1
    console.log("First Executed"); //2
  }, 0);
}

function second() {
  setTimeout(() => {
    console.log("second Executed"); //3
    console.log(" ---- app ended ----"); //4
  }, 0);
}

first();
second();
