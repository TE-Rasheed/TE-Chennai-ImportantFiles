package com.te.ems.service;

import com.te.ems.beans.EmployeeInfo;

public interface EmployeeService {
	
	public EmployeeInfo authenticate(Integer id, String password);
	
	public EmployeeInfo getEmployee(Integer id);
	
}
