package com.te.ems.dao;

import com.te.ems.beans.EmployeeInfo;

public interface EmployeeDAO {
	
	public EmployeeInfo authenticate(Integer id, String password);
	
	public EmployeeInfo getEmployee(Integer id);
}
