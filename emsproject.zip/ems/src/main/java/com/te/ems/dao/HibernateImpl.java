package com.te.ems.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.te.ems.beans.EmployeeInfo;

@Repository
public class HibernateImpl implements EmployeeDAO {

	@Override
	public EmployeeInfo authenticate(Integer id, String password) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPersistenceUnit");
		EntityManager manager = factory.createEntityManager();
		EmployeeInfo info = manager.find(EmployeeInfo.class, id);
		if (info != null) {
			if (info.getPwd().equals(password)) {
				return info;
			}
		}
		return null;
	}//end of authenticate

	@Override
	public EmployeeInfo getEmployee(Integer id) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("emsPersistenceUnit");
		EntityManager manager = factory.createEntityManager();
		EmployeeInfo info = manager.find(EmployeeInfo.class, id);
		return info;
	}

}
