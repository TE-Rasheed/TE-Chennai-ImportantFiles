package com.te.ems.controllers;

import javax.print.attribute.standard.Severity;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.te.ems.beans.EmployeeInfo;
import com.te.ems.dao.EmployeeDAO;
import com.te.ems.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired(required = false)
	private EmployeeService service;

	@GetMapping("/login")
	public String getLoginForm() {
		return "LoginForm";
	}// end of getLoginForm

	@GetMapping("/signup")
	public String getRegForm() {
		return "signUp";
	}// end of getRegForm

	@PostMapping("/login")
	public String authenticate(Integer id, String pwd, ModelMap map, HttpServletRequest request) {
		EmployeeInfo info = service.authenticate(id, pwd);
		if (info != null) {
			HttpSession session = request.getSession(true);
			session.setAttribute("isLoggedIn", info);
			map.addAttribute("user", info);
			return "welcome";
		} else {
			map.addAttribute("err", "Invalid Credentials");
			return "LoginForm";
		}
	}// end of authenticate

	@GetMapping("/searchPage")
	public String getSearchPage(HttpSession session, ModelMap map) {
		if (session.getAttribute("isLoggedIn") != null) {
			return "search";
		} else {
			map.addAttribute("err", "Please Login First");
			return "LoginForm";
		}

	}

	@GetMapping("/search")
	public String sendSearchData(@SessionAttribute(name = "isLoggedIn", required = false) EmployeeInfo info, Integer id,
			ModelMap map) {
		if (info != null) {
			EmployeeInfo info1 = service.getEmployee(id);
			if (info1 != null) {
				map.addAttribute("user", info1);
			} else {
				map.addAttribute("msg", "Data not found");
			}
			return "search";
		} else {
			map.addAttribute("err", "Please Login First");
			return "LoginForm";
		}

	}
}
