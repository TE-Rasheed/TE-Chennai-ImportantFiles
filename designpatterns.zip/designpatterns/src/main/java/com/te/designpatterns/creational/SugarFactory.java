package com.te.designpatterns.creational;

public class SugarFactory implements Factory {

	@Override
	public void production() {
		System.out.println("Producing Sugar ");
		
	}

}
