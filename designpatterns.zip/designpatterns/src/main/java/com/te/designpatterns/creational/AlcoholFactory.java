package com.te.designpatterns.creational;

public class AlcoholFactory implements Factory{

	@Override
	public void production() {
		System.out.println(" Producing Old Monk");
		
	}

}
