package com.te.designpatterns.creational;

public class MathOperationsSingleton {

	//step 1 
	private MathOperationsSingleton() {}
	
	//step 2 
	 static MathOperationsSingleton mathOperations = null;
	
	public static MathOperationsSingleton getMathObejct() {
		if (mathOperations == null) {
			mathOperations = new MathOperationsSingleton();
		}
		return  mathOperations;
	}
	
	
	
	public void add(int a ,int b) {
		System.out.println(a+b);
	}
	
	public void substract(int a , int b) {
		System.out.println(a-b);
	}
}
