package com.te.designpatterns.creational;

public interface Factory {

	public void production();
}
