package com.bcits.springrest.customeception;

public class EntityNotFoundExp  extends RuntimeException{

	public EntityNotFoundExp(String msg) {
		super(msg);
	}
}
