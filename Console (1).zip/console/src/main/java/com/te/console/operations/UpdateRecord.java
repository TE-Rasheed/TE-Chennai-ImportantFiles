package com.te.console.operations;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.te.console.beans.EmployeesInfo;

public class UpdateRecord extends WelcomePage {

	
	public static void update() {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;

		try {
			factory = Persistence.createEntityManagerFactory("console");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();

			transaction.begin();

			EmployeesInfo info = new EmployeesInfo();

			Scanner scan = new Scanner(System.in);

			
			String que = "update EmployeesInfo set name = :nm , salary = :sal  where id = :id";
			Query query = manager.createQuery(que);
			
			System.out.println("==========Update Your Account Details========");
			
			System.out.print("Enter the user new Name : ");
			String str = scan.nextLine();
			System.out.println( );
		
			query.setParameter("nm", str);
			
			System.out.print("Enter the user new Salary : ");
			double doub = scan.nextDouble();
			System.out.println( );
			
			query.setParameter("sal", doub);
			
			System.out.print("Enter the id : ");
			int num = scan.nextInt();
			System.out.println( );
			
			query.setParameter("id", num);
			
			int res = query.executeUpdate();
			
			System.out.println(res + " Number of column got updated");

			transaction.commit();

			System.out.println("=========== Account Updated Successfully ========");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (manager != null) {
				manager.close();
			}
			if (factory != null) {
				factory.close();
			}
		}
	 }
			
		}

