package com.te.console.operations;

import com.te.console.beans.EmployeesInfo;

public interface Login {

	public void login1(EmployeesInfo le);
}
