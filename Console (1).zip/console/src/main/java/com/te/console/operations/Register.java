package com.te.console.operations;

import com.te.console.beans.EmployeesInfo;

public interface Register {

	public void register2(EmployeesInfo info);

}
