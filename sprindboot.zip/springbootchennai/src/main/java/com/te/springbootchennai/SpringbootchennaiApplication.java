package com.te.springbootchennai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootchennaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootchennaiApplication.class, args);
	}

}
