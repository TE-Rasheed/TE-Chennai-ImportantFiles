package com.te.collectionimpl.setimpl;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import com.te.collectionimpl.beans.Student;

public class HashSetStudent {

	public static void main(String[] args) {
		Student student1 = new Student(10, "Kevin");
		Student student2 = new Student(80, "Vignesh");
		Student student3 = new Student(20, "Paul");
		Student student4 = new Student(7, "Stark");

		Set<Student> students = new HashSet<Student>();
		students.add(student1);
		students.add(student2);
		students.add(student3);
		students.add(student4);
//		
//		for (Student student : students) {
//			System.out.println(student);
//		}
//		
//		System.out.println("After sort");
//		ArrayList<Student> arrayList = new ArrayList<Student>(students);
//		Collections.sort(arrayList);
//		for (Student student : arrayList) {
//			System.out.println(student);
//		}

		CopyOnWriteArrayList<Integer> arrayList = new CopyOnWriteArrayList<Integer>();
		arrayList.add(10);
		arrayList.add(20);

		Iterator<Integer> iterator = arrayList.iterator();

		while (iterator.hasNext()) {
			arrayList.add(30);
			System.out.println(iterator.next());
		}
	}
}
