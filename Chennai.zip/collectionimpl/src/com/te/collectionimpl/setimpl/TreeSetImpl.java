package com.te.collectionimpl.setimpl;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetImpl {

	public static void main(String[] args) {

		TreeSet<Integer> treeSet = new TreeSet<Integer>();

		treeSet.add(5);
		treeSet.add(1);
		treeSet.add(3);
		treeSet.add(0);
		treeSet.add(6);
		treeSet.add(2);
		treeSet.add(7);
		treeSet.add(8);
		treeSet.add(4);
		treeSet.add(11);
		treeSet.add(10);

		Iterator<Integer> iterator = treeSet.iterator();
		
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + " ");
		}
		
		System.out.println();
		
		
		TreeSet<Character> characters = new TreeSet<Character>();
		characters.add('A');
		characters.add('a');
		characters.add('Z');
		characters.add('f');
		characters.add('L');
		
		System.out.println(characters);
				
		TreeSet<String> names = new TreeSet<String>();
		names.add("Boopathi");//1
		names.add("Rasheed");//4
		names.add("Kavin");//2
		names.add("nishant");//7
		names.add("Zain");//5
		names.add("vivek");//8
		names.add("lokesh");//6
		names.add("Kishore");//3
		
		System.out.println(names);
	}
}









