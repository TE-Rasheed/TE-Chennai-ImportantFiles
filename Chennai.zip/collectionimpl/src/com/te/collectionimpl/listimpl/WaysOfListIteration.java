package com.te.collectionimpl.listimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class WaysOfListIteration {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(70);
		list.add(80);
		list.add(60);

		System.out.println("--------------- using for ---------------");
		for (int i = 0; i < list.size(); i++) {
			System.out.print(" " + list.get(i));
		}
		System.out.println();

		System.out.println("--------------- using foreach ---------------");

		for (Integer number : list) {
			System.out.print(" " + number);
		}
		System.out.println();

		System.out.println("--------------- using Iterator ---------------");

		Iterator<Integer> itr = list.iterator();
		System.out.println(itr.getClass());
		while (itr.hasNext()) {
			System.out.print(" " + itr.next());
		}
		System.out.println();

		System.out.println("--------------- using ListIterator (Forward) ---------------");
		ListIterator<Integer> listIterator = list.listIterator();
		
		while(listIterator.hasNext()) {
			System.out.print(" " + listIterator.next());
		}
		System.out.println();
		
		System.out.println("--------------- using ListIterator (Backwords) ---------------");
		ListIterator<Integer> iterator = list.listIterator(list.size());
		
		while(iterator.hasPrevious()) {
			System.out.print(" " + iterator.previous());
			
		}
		System.out.println();
	}
}
